INTRODUCTION
------------

Ansible is an open source community project sponsored by Red Hat that automates cloud provisioning, configuration management, application deployment, intra-service orchestration, and many other IT needs.  

Ansible works by connecting to your nodes and pushing out small programs, called "Ansible Playbook" to them. These programs are written to be resource models of the desired state of the system. Ansible then apply these playbooks to all nodes using SSH.

REQUIREMENTS
------------

To apply configuration of state system to some nodes using ansible, require this following conditions :

*	Main server with ansible installed as a gateway for "Ansible Playbook" to your nodes, here is the link for installation guide https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html.
*	Main server's public key are assigned to all nodes so that the main server can access all nodes by using ssh.
*	Public IPv4 address or public DNS of the nodes are assigned in the hosts file in this repository.


example of hosts file:


    [webservers] # groupname of multiple host/node target
    www1.example.com # public dns of the node target
    www2.example.com

    [dbservers]
    username@1.1.1.1 # username and public ip address of the node target
    db1.example.com



BUILD AND DEPLOY
------------
* Build configuration of state system by creating yourplaybookname.yml in this repository that contains all state of system that you want to apply to all nodes in yaml language.  

example of playbook.yml file:  

    ---
    - name: Update web servers
      hosts: webservers
      remote_user: root

      tasks:
      - name: Ensure apache is at the latest version
        ansible.builtin.yum:
          name: httpd
          state: latest
      - name: Write the apache config file
        ansible.builtin.template:
          src: /srv/httpd.j2
          dest: /etc/httpd.conf

for more ansible playbook example, checkout this documentation : https://docs.ansible.com/ansible/latest/user_guide/playbooks.html
* Deploy the playbook.yml by updating the path of playbook with your playbook location in Pipelines -> Release -> Ansible_Pipeline -> Tasks or in this link:  
https://dev.azure.com/DANIS-Indonesia/IT%20-%20Infra%20as%20a%20Code/_releaseDefinition?definitionId=2&_a=definition-tasks&environmentId=2

